import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-batch',
  templateUrl: './update-batch.component.html',
  styleUrls: ['./update-batch.component.scss']
})
export class UpdateBatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
