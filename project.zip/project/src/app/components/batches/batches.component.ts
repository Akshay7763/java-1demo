import { Component, OnInit } from '@angular/core';
import { BatchesService } from 'src/app/utilities/batches.service';

@Component({
  selector: 'app-batches',
  templateUrl: './batches.component.html',
  styleUrls: ['./batches.component.scss'],
})
export class BatchesComponent implements OnInit {
  constructor(private _batchService: BatchesService) {}

  ngOnInit(): void {}

  deleteBatch() {
    this._batchService.deleteSports().subscribe((result) => {
      console.warn(result);
    });
  }

  enableBatch() {
    this._batchService.enableBatch().subscribe((result) => {
      console.warn(result);
    });
  }

  disableBatch() {
    this._batchService.disableBatch().subscribe((result) => {
      console.warn(result);
    });
  }
}
