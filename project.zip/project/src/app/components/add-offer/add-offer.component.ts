import { Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormControlName,
  FormGroup,
  FormGroupName,
} from '@angular/forms';
import { OfferService } from 'src/app/utilities/offer.service';

@Component({
  selector: 'app-add-offer',
  templateUrl: './add-offer.component.html',
  styleUrls: ['./add-offer.component.scss'],
})
export class AddOfferComponent implements OnInit {
  constructor(private _offerService:OfferService) {}

  ngOnInit(): void {}

  addOfferForm = new FormGroup({
    name: new FormControl(''),
    startDate: new FormControl(''),
    endDate: new FormControl(''),
    discount: new FormControl(''),
  });

  addOffer() {
    this.addOfferForm.value.likes = 0;
    this.addOfferForm.value.active = 'true';
    console.warn(this.addOfferForm.value);
    this._offerService.addOffer(this.addOfferForm.value).subscribe((result)=>{
      console.warn(result);
      
    })

    

  }
}
