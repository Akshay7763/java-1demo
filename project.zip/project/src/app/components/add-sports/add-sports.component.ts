import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm } from '@angular/forms';
import { ISports } from 'src/app/utilities/sports';
import { SportsService } from 'src/app/utilities/sports.service';

@Component({
  selector: 'app-add-sports',
  templateUrl: './add-sports.component.html',
  styleUrls: ['./add-sports.component.scss'],
})
export class AddSportsComponent implements OnInit {
  constructor(private _sportsService: SportsService) {}
  isActive: string = '';
  ngOnInit(): void {}

  onSubmit(data: any) {
    console.log(data);
    this._sportsService.addSports(data).subscribe((result) => {
      console.warn(result);
    });
  }

  enableSport() {
    this._sportsService.enableSports().subscribe((result) => {
      console.warn(result);
    });
  }

  disableSport() {
    this._sportsService.disableSports().subscribe((result) => {
      console.warn(result);
    });
  }

  deleteSport() {
    this._sportsService.deleteSports().subscribe((result) => {
      console.warn(result);
    });
  }
}
