import { Component, OnInit } from '@angular/core';
import { SportsService } from 'src/app/utilities/sports.service';
import {
  FormBuilder,
  FormControlName,
  FormControl,
  FormGroup,
  NgForm,
} from '@angular/forms';
import { BatchesService } from 'src/app/utilities/batches.service';

@Component({
  selector: 'app-add-batch',
  templateUrl: './add-batch.component.html',
  styleUrls: ['./add-batch.component.scss'],
})
export class AddBatchComponent implements OnInit {

  // for error
  error: string = ''

  sports: any;
  constructor(
    private fb: FormBuilder,
    private _sportsService: SportsService,
    private _batchService: BatchesService
  ) {
    this._sportsService.getAllsports().subscribe((response) => {
      this.sports = response;
      console.warn(this.sports);
    });
    console.warn(this.sports);
  }

  ngOnInit(): void {}

  onSubmit(data: any) {
    console.log(data);
    this._batchService.addBatch(data).subscribe((result) => {
      console.warn(result);
    });
  }
  addBatchForm = new FormGroup({
    name: new FormControl(''),
    startTime: new FormControl(''),
    endTime: new FormControl(''),
    size: new FormControl(),
    description: new FormControl(''),
    fees: new FormControl(),
    sportId: new FormControl(),
  });

  addBatch() {
    const parsedSportId = Number(this.addBatchForm.get('sportId')?.value);
    // this.addBatchForm.get('sportId')?.setValue(parsedSportId);
    console.log(parsedSportId);

    this.addBatchForm.value.sports = { sportId: parsedSportId };
    delete this.addBatchForm.value.sportId;
    this.addBatchForm.value.active = 'true';
    console.warn(this.addBatchForm.value);
    this._batchService.addBatch(this.addBatchForm.value).subscribe((result) => {
      console.warn(result);
    },(error) => {this.error = error.error;
    alert(this.error)
    });
  }
}
