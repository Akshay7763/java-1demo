import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddSportsComponent } from './components/add-sports/add-sports.component';
import { AddBatchComponent } from './components/add-batch/add-batch.component';
import { UpdateBatchComponent } from './components/update-batch/update-batch.component';
import { BatchesComponent } from './components/batches/batches.component';
import { AddOfferComponent } from './components/add-offer/add-offer.component';
import { OfferComponent } from './components/offer/offer.component';
import { AuthenticateComponent } from './components/authenticate/authenticate.component';

@NgModule({
  declarations: [AppComponent, AddSportsComponent, AddBatchComponent, UpdateBatchComponent, BatchesComponent, AddOfferComponent, OfferComponent, AuthenticateComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
