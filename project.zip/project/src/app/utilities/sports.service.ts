import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ISports } from './sports';

@Injectable({
  providedIn: 'root',
})
export class SportsService {
  baseURL: string = 'http://localhost:8080/';
  constructor(private _http: HttpClient) {}

  //add sports
  userid: number = 1;
  addSports(data: any) {
    console.warn('URL re:' + this.baseURL + 'sports/addSport');
    return this._http.post(
      this.baseURL + 'sports/addSport/' + this.userid,
      data
    );
  }

  // enable  sports
  sportid: number = 6;
  enableSports() {
    console.warn(
      'enable URL: ' +
        this.baseURL +
        'sports/enableSport/' +
        this.sportid +
        '/' +
        this.userid
    );
    return this._http.get(
      this.baseURL + 'sports/enableSport/' + this.sportid + '/' + this.userid
    );
  }

  // disable  sports
  disableSports() {
    console.warn(
      'enable URL: ' +
        this.baseURL +
        'sports/disableSport/' +
        this.sportid +
        '/' +
        this.userid
    );
    return this._http.get(
      this.baseURL + 'sports/disableSport/' + this.sportid + '/' + this.userid
    );
  }

  //delete sports
  deleteSports() {
    return this._http.delete(
      this.baseURL + 'sports/deleteSports/' + this.sportid + '/' + this.userid
    );
  }

  //getall sports
  getAllsports(): Observable<any> {
    return this._http.get(this.baseURL + 'sports/getAllSports');
  }
}
