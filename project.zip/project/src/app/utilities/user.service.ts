import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private _http: HttpClient) {}
  baseURL: string = 'http://localhost:8080/';

  email = "";
  pass = "";
  //authenticate
  login() {
    return this._http.get(
      this.baseURL + 'authenticateUser/' + this.email + '/' + this.pass
    );
  }
}
