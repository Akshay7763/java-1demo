export interface ISports{
    id: number;
    sportsName: string;
    isActive: string;
}