import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class OfferService {
  constructor(private _http: HttpClient) {}
  baseURL: string = 'http://localhost:8080/';

  userid = 1;
  //add offer
  addOffer(data: any) {
    return this._http.post(
      this.baseURL + 'offers/addOffer/' + this.userid,
      data
    );
  }
}
