import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class BatchesService {
  baseURL: string = 'http://localhost:8080/';
  constructor(private _http: HttpClient) {}

  //add batch
  userid: number = 1;
  addBatch(data: any) {
    return this._http.post(
      this.baseURL + 'batches/addBatch/' + this.userid,
      data
    );
  }

  batchId = 1;
  //delete batch
  deleteSports() {
    return this._http.delete(
      this.baseURL + 'batches/deleteBatch/' + this.batchId + '/' + this.userid
    );
  }

  //enable batch
  enableBatch() {
    return this._http.get(
      this.baseURL + 'batches/enableBatch/' + this.batchId + '/' + this.userid
    );
  }

  //disable batch
  disableBatch() {
    return this._http.get(
      this.baseURL + 'batches/disableBatch/' + this.batchId + '/' + this.userid
    );
  }
}
